# Tracepad

**让您的iPhone/iPad设备成为Mac电脑的触控板**



[中文, [English](.tracepad-en.html)]


## 下载
- **<a href="../OSX-APP/{placeholder}" download><span style="color: orange">Mac</span></a>**

- **<a href="https://apps.apple.com/app/id{placeholder}"><span style="color: orange">iPhone/iPad</span></a>**


## 开始使用

1. 在您的iPhone/iPad端与Mac端下载并打开Tracepad APP，并**授予相应权限**
2. 配对您的iPhone/iPad与Mac设备，您可以通过以下两种方式进行配对
    - 无线方式：打开设备上的**蓝牙/WIFI**，Tracepad会自动发现对方并连接
    - 有线方式（推荐）：使用**数据线**连接您的iPhone/iPad与Mac设备，此种方式将获得更稳定的使用体验
3. 尽情使用吧


## FAQ

### 使用有线方式连接后仍旧无法使用
- 如果您的APP不是最新的，请将双端APP更新到最新版本
- 双端重启APP
- 更换数据线
- 更换插入的USB/Type-C口

### Mac端显示无线已连接，却仍旧无法使用
- 如果您的APP不是最新的，请将双端APP更新到最新版本
- 双端重启APP
- 确认您在Mac上授予Tracepad辅助功能权限，您可以前往 `设置->安全性与隐私->隐私->辅助功能` 中进行查看


### Mac端无法安装Tracepad
- 右键点击Tracepad图标后打开
- 按住 `control` 后，再次点击Tracepad图标
- 修改系统偏好设置，允许从任何来源安装APP，您可以前往 `设置->安全性与隐私->通用` 中进行设置

### 部分手势无法识别
- 如果您需要在iPad设备上使用4指手势，请在iPad设备上前往设置关闭系统多任务手势

#### 如果以上方法均无法解决您遇到的问题，您可以在iPhone/iPad端App的设置内联系我


### Tracepad不会收集您的任何隐私信息，请放心使用
